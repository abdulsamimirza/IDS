import requests
import json
import mysql.connector



content = requests.get("https://urlhaus-api.abuse.ch/v1/payloads/recent/")
for i in range(0,10):
	hash = json.loads(content.text)["payloads"][i]["sha256_hash"]
	print(hash)




 