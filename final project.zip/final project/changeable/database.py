import mysql.connector

# Connect to the local MySQL server
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sami"
)

# Create a cursor object to interact with the database
cursor = connection.cursor()

# Insert a record into a table
query = "INSERT INTO `hashes`(`id`, `hashes`, `blank1`, `blank2`, `blan3`) VALUES ('','hash','','','')"
cursor.execute(query)

# Commit the changes to the database
connection.commit()

# Close the cursor and connection
cursor.close()
connection.close()
