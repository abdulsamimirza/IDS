import hashlib
import os

def generate_signature(filename):
    with open(filename, 'rb') as file:
        data = file.read()
        signature = hashlib.sha256(data).hexdigest()
        # signature = hashlib.sha3(data).hexdigest()
        # signature = hashlib.blake2b(data).hexdigest()
        # signature = hashlib.blake2s(data).hexdigest()
        # signature = hashlib.sha1(data).hexdigest()
        # signature = hashlib.md5(data).hexdigest()
        return signature

value = generate_signature("sample.txt")
print(value)