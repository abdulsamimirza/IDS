import requests
import json
import mysql.connector

# Connect to the local MySQL server
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="hashes"
)

# Create a cursor object to interact with the database
cursor = connection.cursor()

# Fetch recent payloads from the API
content = requests.get("https://urlhaus-api.abuse.ch/v1/payloads/recent/")
for i in range(0, 1000):
    # Extract the SHA256 hash
    hash = json.loads(content.text)["payloads"][i]["sha256_hash"]
    # print(hash)
    # Insert the hash into the database
    query = "INSERT INTO hashes VALUES (%s,%s)"
    data = ('',hash)
    cursor.execute(query, data)

# Commit the changes to the database
connection.commit()

# Close the cursor and connection
cursor.close()
connection.close()
