import mysql.connector

# Connect to the local MySQL server
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="hashes"
)

# Create a cursor object to interact with the database
cursor = connection.cursor()

# Fetch data from the database
select_query = "SELECT * FROM hashes"
cursor.execute(select_query)
data = cursor.fetchall()

# Sort the data based on the second column
sorted_data = sorted(data, key=lambda x: x[1])

# Delete previous records from the table
delete_query = "DELETE FROM hashes"
cursor.execute(delete_query)

# Restore the sorted data back into the table
insert_query = "INSERT INTO hashes (id, hashes) VALUES (%s, %s)"
cursor.executemany(insert_query, sorted_data)

# Commit the changes to the database
connection.commit()

# Close the cursor and connection
cursor.close()
connection.close()
