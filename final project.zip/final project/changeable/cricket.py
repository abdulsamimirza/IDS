import requests
content = requests.get("https://www.apple.com/")
print(content.text)