import hashlib
import os
import mysql.connector

config = {
  'user': 'root', # default username for XAMPP
  'password': '', # default password for XAMPP
  'host': 'localhost',
  'database': 'sami'
}

cnx = mysql.connector.connect(**config)

# Create a cursor object
cursor = cnx.cursor()

# Execute a query
query = "SELECT * FROM hashes;"
cursor.execute(query)

# Fetch the results
results = cursor.fetchall()

# Do something with the results


# Close the connection
cnx.close()

data = [
    "eef10ef2e6f73ee37fd1757eeeb4eb2dce55172fd06f1b38e6b0d9d2972fab68",                                                      
    "926951d83b03064141f17259a835fd47b85ebe0d7c232c1be2f14fb8ec0f8b9e",                                                        
    "47ac30c2502d7afcf31e5411248dba37aa9814e77247c162a45341f2f89b15b1",                                                        
    "1e80d8fbdb780ee47c30c21c9573d8b02cf3af2a685cafa9aaa33539b587ebd4",                                                       
    "0c9a79e3478bd308b66246a5fe27cb0d6c3328bde6be71d6b35e7ac7246b1bc1",                                                        
    "358860b5b9c81fb109d69291f5d307374f0987ab78ff1334e023037c6a9963ab",                                                        
    "f0195e6f0132c1db84ddfe7d3386068900096b8a4246579fb838002804255a86",                                                        
    "cead4e976b01d5ff2e4ce5a28dd94e49f6ff250c946c2af84de84ebf9f50de2f",                                                        
    "c6cbfe93e155e9f11aa22b3796b5c26c095744eafa2d65163d0e42b7660f6acb",                                                        
    "0ab31b93422a03d804ac961e4ff62fa61e7936170031eb5dfe7cdd6a5d404f23", 
    "7b72dd535013f7d30691fc3491dd5a9a3c43dda41539cc253100f49857af8030",
]

data1 = sorted(data)

def generate_signature(filename):
    with open(filename, 'rb') as file:
        data = file.read()
        signature = hashlib.sha256(data).hexdigest()
        # signature = hashlib.sha3(data).hexdigest()
        # signature = hashlib.blake2b(data).hexdigest()
        # signature = hashlib.blake2s(data).hexdigest()
        # signature = hashlib.sha1(data).hexdigest()
        # signature = hashlib.md5(data).hexdigest()
        return signature
loop_files = []
def scan():
    drive = "E:\\final_year_project"
    for root, dirs, files in os.walk(drive):
        for file in files:
            file_path = os.path.join(root, file)
            signature_value = generate_signature(file_path)
            #print(signature_value)
            check = signature_value
            for row in results:
                b = False
                if(row[1][0]==check[0]):
                    if(row[1][1]==check[1]):
                        if(row[1][2]==check[2]):
                            if(row[1]==check):
                                b = True
                                #print("found")
                                loop_files.append(file_path)
                                break
            #if(b==False):
            #    print("Not Found")
    print(loop_files)

scan()

def delete_file():
    if len(loop_files) > 0:
        for file_path in loop_files:
            answer = input("\033[37m" + "Do you want to remove " + file_path + "? (yes/no): " + "\033[0m")
            if answer.lower() == "yes":
                os.remove(file_path)
                print("\033[32m" + file_path, "has been removed." + "\033[0m")
            else:
                print("\033[91m" + file_path, "will not be removed." + "\033[0m")
    else:
        print("\033[32m" + "No matched files were found." + "\033[0m")

delete_file()



        # for i in range(0,len(data1)):
        #     b = False
        #     if(check[0]==data1[i][0]):
        #         if(check[1]==data1[i][1]):
        #             if(check[2]==data1[i][2]):
        #                 if(check==data1[i]):
        #                     b = True
        #                     print("found")
        #                     break
        # if(b==False):
        #     print("Not Found")

