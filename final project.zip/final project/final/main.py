import hashlib
import os
import mysql.connector

config = {
  'user': 'root',
  'password': '',
  'host': 'localhost',
  'database': 'hashes'
}

cnx = mysql.connector.connect(**config)


cursor = cnx.cursor()


query = "SELECT * FROM hashes;"
cursor.execute(query)


results = cursor.fetchall()





cnx.close()

def generate_signature(filename):
    with open(filename, 'rb') as file:
        data = file.read()
        signature = hashlib.sha256(data).hexdigest()
        return signature
loop_files = []


def scan():
    drive = "E:\\final_year_project"
    for root, dirs, files in os.walk(drive):
        for file in files:
            file_path = os.path.join(root, file)
            signature_value = generate_signature(file_path)
            # print(signature_value)
            check = signature_value
            for row in results:
                b = False
                if(row[1][0]==check[0]):
                    if(row[1][1]==check[1]):
                        if(row[1][2]==check[2]):
                            if(row[1]==check):
                                b = True
                                #print("found")
                                loop_files.append(file_path)
                                break
            # if(b==False):
            #    print("Not Found")
    print(loop_files)


def delete_file():
    if len(loop_files) > 0:
        for file_path in loop_files:
            # answer = input("\033[37m" + "Do you want to remove " + file_path + "? (yes/no): " + "\033[0m")
            answer = input("Do you want to remove " + file_path + "? (yes/no):")
            if answer.lower() == "yes":
                os.remove(file_path)
                print(file_path, "has been removed.")
            else:
                print(file_path, "will not be removed.")
    else:
        print("No matched files were found.")


scan()
delete_file()



