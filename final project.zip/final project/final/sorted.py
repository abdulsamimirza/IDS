import mysql.connector


connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="hashes"
)


cursor = connection.cursor()


select_query = "SELECT * FROM hashes"
cursor.execute(select_query)
data = cursor.fetchall()


sorted_data = sorted(data, key=lambda x: x[1])


delete_query = "DELETE FROM hashes"
cursor.execute(delete_query)


insert_query = "INSERT INTO hashes (id, hashes) VALUES (%s, %s)"
cursor.executemany(insert_query, sorted_data)

connection.commit()


cursor.close()
connection.close()
